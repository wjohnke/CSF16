<!DOCTYPE html>
<html>
<head>
	<title>Session Error</title>
	<style>
        body {
            text-align: center;
        }
		.error {
			color: red;
		}
	</style>
</head>
<body>
	<h1 class="error">Error</h1>
	<p>There was an error starting a session.</p>
    <p>Please contact the system administrator.</p>
</body>
</html>