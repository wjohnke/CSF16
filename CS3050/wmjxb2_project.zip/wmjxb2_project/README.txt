Will Johnke
ID: 14253530
CS 3050 Final Project

*************************

My program's built in java using netbeans.
It will ask for how many milliseconds you want to wait in between
movements, depending on what you want to see, then will cycle through and
print out each movement to the standard output stream. 

If the robot reaches the end goal, it will print out that you have won, and end.
Otherwise, it will print out that you lost and will end.

**************************